
            #                                    | self.11  self.12   0 |
            # point' = | src.self.x  src._my  1 | x | self.21  self.22   0 |
            #                                    | self.tx  self.ty   1 |
