
     wx.App.SetTopWindow(None)
