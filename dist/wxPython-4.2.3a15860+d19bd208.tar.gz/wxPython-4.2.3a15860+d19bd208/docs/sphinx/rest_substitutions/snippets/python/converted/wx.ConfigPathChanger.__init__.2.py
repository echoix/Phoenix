
            wx.ConfigPathChanger(wx.ConfigBase.Get(), "/MyProgram/")
